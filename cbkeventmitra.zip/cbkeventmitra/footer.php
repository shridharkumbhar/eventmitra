<footer class="site-footer-bottom">
<div class="container">
  <div class="row">
    <div class="col-md-12 ">
      <p class="text-center">&copy; <?php echo date('Y');?> Event Mitra. All Rights Reserved.</p>
    </div>
  </div>
</div>
</footer>

<a id="back-to-top"><i class="fa fa-angle-double-up"></i></a> 